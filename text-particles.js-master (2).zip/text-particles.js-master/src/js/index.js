import '../styles/index.sass';
import textParticles from '../../lib/text-particles.js';

textParticles.accelerate({
  textSize: 20,
  particleSize: 2,
});
